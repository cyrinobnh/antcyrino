#!/bin/bash

ROOT_DIR=$(pwd)

for APP in */; do
  APP_NAME=$(basename "$APP")
  [ "$APP_NAME" == "encode_secrets.sh" ] && continue

  echo "======================================"
  echo "Encoding for App: $APP_NAME"
  echo "======================================"

  for ENV in DEV QA PROD; do
    ENV_DIR="$ROOT_DIR/$APP_NAME/$ENV"
    OUTPUT_DIR="$ENV_DIR/secrets"
    mkdir -p "$OUTPUT_DIR"

    if [ -d "$ENV_DIR" ]; then
      echo "[*] Environment: $ENV"

      for FILE in bh-commons.xml log4j.xml weblogic.xml local.properties; do
        SRC_FILE="$ENV_DIR/$FILE"
        BASE_NAME=$(basename "$FILE" .xml | sed 's/\.properties//g' | tr '-' '_')
        SECRET_NAME=$(echo "${APP_NAME}_${BASE_NAME}_B64_${ENV}" | tr '[:lower:]' '[:upper:]')
        OUT_FILE="$OUTPUT_DIR/${SECRET_NAME}.txt"

        if [ -f "$SRC_FILE" ]; then
          base64 -w 0 "$SRC_FILE" > "$OUT_FILE"
          echo "✅ Encoded: $SRC_FILE → $OUT_FILE"
          echo "🔐 GitHub Secret Suggestion: $SECRET_NAME"
        else
          echo "⚠️  Missing file: $SRC_FILE"
        fi
      done

      echo ""
    fi
  done
done
