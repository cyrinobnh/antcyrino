#!/bin/bash
/u01/oracle/user_projects/domains/base_domain/bin/startWebLogic.sh
