#!/bin/bash

for ENV in DEV QA PROD; do
  echo "[*] Encoding files for environment: $ENV"

  base64 -w 0 ./envs/$ENV/bh-commons.xml       > bh_commons_${ENV}_b64.txt
  base64 -w 0 ./envs/$ENV/log4j.xml            > log4j_${ENV}_b64.txt
  base64 -w 0 ./envs/$ENV/weblogic.xml         > weblogic_${ENV}_b64.txt
  base64 -w 0 ./envs/$ENV/local.properties     > local_properties_${ENV}_b64.txt
done
